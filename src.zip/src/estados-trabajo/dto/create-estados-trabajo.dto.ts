export class CreateEstadosTrabajoDto {}
